<footer class="vestclo-footer">
  Developed by <a target="_blank" href="https://www.instagram.com/cahyaajipermana">cahyaajipermana</a> | cahyaajipermana@gmail.com
</footer>